# Front-end screening test

### Task:

- Replicate design figma

### Waktu:

- 3 hari

### Teknologi

- React JS
- ReduxThunk
- React Native
- React Hooks
- Eslint standard Airbnb
- sass/less/preprocessor css
- Rest API
