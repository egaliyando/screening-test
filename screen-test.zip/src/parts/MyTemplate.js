import React from 'react';

function MyTemplate() {
  return (
    <div className="tab-pane fade" id="my-template" role="tabpanel">
      <div className="row">
        <p>halo</p>
      </div>
    </div>
  );
}

export default MyTemplate;
